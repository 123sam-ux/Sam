# WinSec GUI Tool

A basic Windows security tool with GUI, built using Python and Tkinter.

## Features

- **Scan System**: Counts temporary files in key system folders.
- **Update Definitions**: Simulates an update and logs timestamp.
- **Firewall Settings**: Opens Windows Defender Firewall settings.

## How to Run

1. Install Python on your Windows PC.
2. Run: `python winsec_gui.py`

Enjoy!