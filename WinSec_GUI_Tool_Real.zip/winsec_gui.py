import tkinter as tk
from tkinter import messagebox
import os
import subprocess
from datetime import datetime

def scan_system():
    temp_paths = [r"C:\Windows\Temp", r"C:\Temp"]
    total_files = 0
    for path in temp_paths:
        if os.path.exists(path):
            total_files += len(os.listdir(path))
    messagebox.showinfo("Scan Result", f"Found {total_files} temp files in system folders.")

def update_definitions():
    with open("last_update.txt", "w") as f:
        f.write(f"Definitions updated on: {datetime.now()}\n")
    messagebox.showinfo("Update", "Security definitions updated successfully.")

def firewall_settings():
    try:
        subprocess.run(["control", "/name", "Microsoft.WindowsFirewall"], check=True)
    except Exception as e:
        messagebox.showerror("Error", f"Could not open firewall settings.\n{str(e)}")

app = tk.Tk()
app.title("WinSec GUI Tool")
app.geometry("350x220")

tk.Button(app, text="Scan System", command=scan_system, width=25).pack(pady=10)
tk.Button(app, text="Update Definitions", command=update_definitions, width=25).pack(pady=10)
tk.Button(app, text="Firewall Settings", command=firewall_settings, width=25).pack(pady=10)

app.mainloop()