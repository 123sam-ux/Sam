# WinSec GUI Tool

**WinSec GUI Tool** is a beginner-friendly Windows GUI application created by **Samson Siachalinga**. Designed for educational and personal security project experiments, this tool offers a simple interface with buttons simulating basic security utilities.

## Creator

**Samson Siachalinga**  
Developer | Digital Explorer | Innovator

## Features

- User-friendly GUI with clickable security-themed buttons
- Great for Python learners exploring GUI development
- Clean design and beginner-safe logic
- Convertible to a standalone `.exe` for Windows

## Technologies Used

- Python 3
- Tkinter (built-in GUI module)

## Installation

> For PC Users:

### Step 1: Clone the Repository

```bash
git clone https://github.com/123sam-ux/Sam.git
cd Sam
```

### Step 2: Run the App

```bash
python winsec_gui.py
```

Ensure Python is installed on your machine.

## Convert to .exe (For Windows Only)

To distribute as a Windows application:

```bash
pip install pyinstaller
pyinstaller --onefile --windowed winsec_gui.py
```

The `.exe` file will be inside the `dist` folder.

## Coming Soon

- Screenshot preview
- Extra GUI features
- Theme selector

## License

This project is open-source and licensed under the **MIT License**.

---

Created with intention and curiosity by **Samson Siachalinga**.
