import tkinter as tk
from tkinter import messagebox

def scan_system():
    messagebox.showinfo("Scan", "System scan started...")

def update_definitions():
    messagebox.showinfo("Update", "Security definitions updated.")

def firewall_settings():
    messagebox.showinfo("Firewall", "Firewall settings opened.")

app = tk.Tk()
app.title("WinSec GUI Tool")
app.geometry("300x200")

tk.Button(app, text="Scan System", command=scan_system).pack(pady=10)
tk.Button(app, text="Update Definitions", command=update_definitions).pack(pady=10)
tk.Button(app, text="Firewall Settings", command=firewall_settings).pack(pady=10)

app.mainloop()
