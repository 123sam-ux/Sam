import tkinter as tk
from tkinter import scrolledtext
import socket
import subprocess
import psutil
import threading
import time

class WinSecApp:
    def __init__(self, root):
        self.root = root
        root.title("WinSec Toolkit")
        root.geometry("600x700")

        tk.Label(root, text="Target IP / Hostname:").pack()
        self.target_entry = tk.Entry(root, width=40)
        self.target_entry.pack(pady=5)

        tk.Button(root, text="Port Scanner", command=self.port_scanner).pack(pady=5)
        tk.Button(root, text="Wi-Fi Scanner", command=self.wifi_scanner).pack(pady=5)
        tk.Button(root, text="Start CPU & RAM Monitor", command=self.start_resource_monitor).pack(pady=5)

        self.output = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=70, height=30)
        self.output.pack(padx=10, pady=10)

    def print_output(self, message):
        self.output.insert(tk.END, f"{message}\n")
        self.output.see(tk.END)

    def port_scanner(self):
        target = self.target_entry.get().strip()
        if not target:
            self.print_output("Please enter a target IP or domain.")
            return

        self.print_output(f"\nScanning {target} from ports 1–1024...\n")
        try:
            for port in range(1, 1025):
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(0.2)
                    result = s.connect_ex((target, port))
                    if result == 0:
                        self.print_output(f"Port {port} is OPEN")
        except Exception as e:
            self.print_output(f"Error scanning: {e}")

    def wifi_scanner(self):
        self.print_output("\nScanning Wi-Fi networks...\n")
        try:
            result = subprocess.run(['netsh', 'wlan', 'show', 'networks', 'mode=Bssid'],
                                    capture_output=True, text=True)
            self.print_output(result.stdout)
        except Exception as e:
            self.print_output(f"Error scanning Wi-Fi: {e}")

    def start_resource_monitor(self):
        def monitor():
            while True:
                cpu = psutil.cpu_percent()
                ram = psutil.virtual_memory().percent
                self.print_output(f"CPU: {cpu}% | RAM: {ram}%")
                time.sleep(5)
        threading.Thread(target=monitor, daemon=True).start()

if __name__ == "__main__":
    root = tk.Tk()
    app = WinSecApp(root)
    root.mainloop()
