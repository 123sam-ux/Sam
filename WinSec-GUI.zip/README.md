# WinSec GUI Toolkit

A simple Windows security tool built in Python using Tkinter.

## Features

- **Port Scanner**: Scan open ports on a target IP or domain.
- **Wi-Fi Scanner**: List nearby Wi-Fi networks.
- **CPU & RAM Monitor**: Display real-time system resource usage.

## Installation

1. Clone the repository:

```bash
git clone https://github.com/yourusername/WinSec-GUI.git
cd WinSec-GUI
```

2. Install required packages:

```bash
pip install -r requirements.txt
```

## Usage

```bash
python winsec_gui.py
```

## Build as Windows Executable

```bash
pip install pyinstaller
pyinstaller --onefile --windowed winsec_gui.py
```
