import tkinter as tk
from tkinter import messagebox
import os
import subprocess
from datetime import datetime
import shutil
import psutil
import speedtest

def scan_system():
    temp_paths = [r"C:\Windows\Temp", r"C:\Temp"]
    total_files = 0
    for path in temp_paths:
        if os.path.exists(path):
            total_files += len(os.listdir(path))
    messagebox.showinfo("Scan Result", f"Found {total_files} temp files in system folders.")

def update_definitions():
    with open("last_update.txt", "w") as f:
        f.write(f"Definitions updated on: {datetime.now()}\n")
    messagebox.showinfo("Update", "Security definitions updated successfully.")

def firewall_settings():
    try:
        subprocess.run(["control", "/name", "Microsoft.WindowsFirewall"], check=True)
    except Exception as e:
        messagebox.showerror("Error", f"Could not open firewall settings.\n{str(e)}")

def clear_temp_files():
    temp_paths = [r"C:\Windows\Temp", r"C:\Temp"]
    deleted = 0
    for path in temp_paths:
        if os.path.exists(path):
            for file in os.listdir(path):
                try:
                    full_path = os.path.join(path, file)
                    if os.path.isfile(full_path) or os.path.islink(full_path):
                        os.remove(full_path)
                        deleted += 1
                    elif os.path.isdir(full_path):
                        shutil.rmtree(full_path)
                        deleted += 1
                except Exception:
                    continue
    messagebox.showinfo("Cleanup", f"Deleted {deleted} temp files/folders.")

def show_ram_usage():
    mem = psutil.virtual_memory()
    usage = f"Total: {mem.total // (1024 ** 2)}MB\nUsed: {mem.used // (1024 ** 2)}MB\nAvailable: {mem.available // (1024 ** 2)}MB"
    messagebox.showinfo("RAM Usage", usage)

def internet_speed():
    st = speedtest.Speedtest()
    download = st.download() / 1_000_000
    upload = st.upload() / 1_000_000
    messagebox.showinfo("Internet Speed", f"Download: {download:.2f} Mbps\nUpload: {upload:.2f} Mbps")

app = tk.Tk()
app.title("WinSec GUI Tool - Extended")
app.geometry("380x400")

tk.Button(app, text="Scan System", command=scan_system, width=30).pack(pady=5)
tk.Button(app, text="Update Definitions", command=update_definitions, width=30).pack(pady=5)
tk.Button(app, text="Firewall Settings", command=firewall_settings, width=30).pack(pady=5)
tk.Button(app, text="Clear Temp Files", command=clear_temp_files, width=30).pack(pady=5)
tk.Button(app, text="Check RAM Usage", command=show_ram_usage, width=30).pack(pady=5)
tk.Button(app, text="Internet Speed Test", command=internet_speed, width=30).pack(pady=5)

app.mainloop()