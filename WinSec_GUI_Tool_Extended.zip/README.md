# WinSec GUI Tool (Extended)

A more powerful version of the basic Windows security tool, built using Python and Tkinter.

## New Features

- **Clear Temp Files**: Deletes files in system temp folders.
- **Check RAM Usage**: Displays memory usage with `psutil`.
- **Internet Speed Test**: Tests your connection with `speedtest`.

## Setup

Make sure you have these packages installed:
```
pip install psutil speedtest-cli
```

## Run the Tool

```
python winsec_gui_extended.py
```